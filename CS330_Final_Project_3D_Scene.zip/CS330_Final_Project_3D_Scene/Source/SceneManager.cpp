///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Updated for CS-330 Milestone Four
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#include <iostream>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize all texture slots so the IDs are never undefined.
	m_loadedTextures = 0;

	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "";
		m_textureIDs[i].ID = 0;
	}
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;

	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  Loads an image file into OpenGL texture memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	if (m_loadedTextures >= 16)
	{
		std::cout
			<< "Texture limit reached. Could not load: "
			<< filename
			<< std::endl;

		return false;
	}

	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	// Normal Visual Studio working directory:
	// CS330Content/Projects/7-1_FinalProjectMilestones
	std::string texturePath = filename;

	unsigned char* image = stbi_load(
		texturePath.c_str(),
		&width,
		&height,
		&colorChannels,
		0);

	// When the EXE is launched directly from Debug/Release,
	// the project assets are one directory higher.
	if (image == nullptr)
	{
		texturePath = "../" + std::string(filename);

		image = stbi_load(
			texturePath.c_str(),
			&width,
			&height,
			&colorChannels,
			0);
	}

	if (image == nullptr)
	{
		std::cout
			<< "Could not load texture image: "
			<< filename
			<< std::endl;

		return false;
	}

	glGenTextures(
		1,
		&textureID);

	glBindTexture(
		GL_TEXTURE_2D,
		textureID);

	// REPEAT is required for the tiled wood technique.
	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_WRAP_S,
		GL_REPEAT);

	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_WRAP_T,
		GL_REPEAT);

	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);

	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_MAG_FILTER,
		GL_LINEAR);

	glPixelStorei(
		GL_UNPACK_ALIGNMENT,
		1);

	if (colorChannels == 3)
	{
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RGB8,
			width,
			height,
			0,
			GL_RGB,
			GL_UNSIGNED_BYTE,
			image);
	}
	else if (colorChannels == 4)
	{
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RGBA8,
			width,
			height,
			0,
			GL_RGBA,
			GL_UNSIGNED_BYTE,
			image);
	}
	else
	{
		std::cout
			<< "Unsupported texture channel count for: "
			<< filename
			<< std::endl;

		stbi_image_free(image);

		glBindTexture(
			GL_TEXTURE_2D,
			0);

		return false;
	}

	glGenerateMipmap(
		GL_TEXTURE_2D);

	stbi_image_free(image);

	glBindTexture(
		GL_TEXTURE_2D,
		0);

	m_textureIDs[m_loadedTextures].ID = textureID;
	m_textureIDs[m_loadedTextures].tag = tag;
	m_loadedTextures++;

	std::cout
		<< "Loaded texture: "
		<< texturePath
		<< std::endl;

	return true;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  Binds the loaded textures to individual texture units.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(
			GL_TEXTURE0 + i);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  Releases the OpenGL texture objects.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].ID != 0)
		{
			glDeleteTextures(
				1,
				&m_textureIDs[i].ID);

			m_textureIDs[i].ID = 0;
		}
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  Finds the OpenGL ID associated with a texture tag.
 ***********************************************************/
int SceneManager::FindTextureID(
	std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
		{
			return static_cast<int>(
				m_textureIDs[i].ID);
		}
	}

	return -1;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  Finds the texture unit associated with a texture tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(
	std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
		{
			return i;
		}
	}

	return -1;
}

/***********************************************************
 *  FindMaterial()
 *
 *  Finds a material definition by its tag.
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	for (size_t i = 0; i < m_objectMaterials.size(); i++)
	{
		if (m_objectMaterials[i].tag == tag)
		{
			material = m_objectMaterials[i];
			return true;
		}
	}

	return false;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Sets scale, rotation, and position for the next mesh.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale =
		glm::scale(scaleXYZ);

	rotationX =
		glm::rotate(
			glm::radians(XrotationDegrees),
			glm::vec3(1.0f, 0.0f, 0.0f));

	rotationY =
		glm::rotate(
			glm::radians(YrotationDegrees),
			glm::vec3(0.0f, 1.0f, 0.0f));

	rotationZ =
		glm::rotate(
			glm::radians(ZrotationDegrees),
			glm::vec3(0.0f, 0.0f, 1.0f));

	translation =
		glm::translate(positionXYZ);

	modelView =
		translation *
		rotationX *
		rotationY *
		rotationZ *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Applies a solid color to the next object.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Applies a loaded texture to the next object.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	int textureSlot =
		FindTextureSlot(textureTag);

	if (textureSlot >= 0)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureSlot);
	}
	else
	{
		// Fall back to color rendering if the texture is missing.
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Controls texture repetition across the next mesh.
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Passes a selected material to the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	OBJECT_MATERIAL material;

	if (FindMaterial(
		materialTag,
		material))
	{
		m_pShaderManager->setVec3Value(
			"material.ambientColor",
			material.ambientColor);

		m_pShaderManager->setFloatValue(
			"material.ambientStrength",
			material.ambientStrength);

		m_pShaderManager->setVec3Value(
			"material.diffuseColor",
			material.diffuseColor);

		m_pShaderManager->setVec3Value(
			"material.specularColor",
			material.specularColor);

		m_pShaderManager->setFloatValue(
			"material.shininess",
			material.shininess);
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the Phong material properties used throughout
 *  the final desk scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL deskMaterial;
	deskMaterial.ambientColor = glm::vec3(0.40f, 0.36f, 0.32f);
	deskMaterial.ambientStrength = 0.34f;
	deskMaterial.diffuseColor = glm::vec3(0.82f, 0.78f, 0.72f);
	deskMaterial.specularColor = glm::vec3(0.34f, 0.34f, 0.34f);
	deskMaterial.shininess = 24.0f;
	deskMaterial.tag = "deskMaterial";
	m_objectMaterials.push_back(deskMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.32f, 0.32f, 0.35f);
	plasticMaterial.ambientStrength = 0.32f;
	plasticMaterial.diffuseColor = glm::vec3(0.72f, 0.72f, 0.75f);
	plasticMaterial.specularColor = glm::vec3(0.42f, 0.42f, 0.46f);
	plasticMaterial.shininess = 28.0f;
	plasticMaterial.tag = "plasticMaterial";
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.46f, 0.47f, 0.50f);
	metalMaterial.ambientStrength = 0.30f;
	metalMaterial.diffuseColor = glm::vec3(0.82f, 0.84f, 0.88f);
	metalMaterial.specularColor = glm::vec3(0.95f, 0.95f, 1.00f);
	metalMaterial.shininess = 64.0f;
	metalMaterial.tag = "metalMaterial";
	m_objectMaterials.push_back(metalMaterial);

	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(1.00f, 1.00f, 1.00f);
	screenMaterial.ambientStrength = 0.78f;
	screenMaterial.diffuseColor = glm::vec3(0.34f, 0.34f, 0.36f);
	screenMaterial.specularColor = glm::vec3(0.12f, 0.12f, 0.14f);
	screenMaterial.shininess = 8.0f;
	screenMaterial.tag = "screenMaterial";
	m_objectMaterials.push_back(screenMaterial);

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.70f, 0.70f, 0.66f);
	ceramicMaterial.ambientStrength = 0.36f;
	ceramicMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.86f);
	ceramicMaterial.specularColor = glm::vec3(0.62f, 0.62f, 0.62f);
	ceramicMaterial.shininess = 48.0f;
	ceramicMaterial.tag = "ceramicMaterial";
	m_objectMaterials.push_back(ceramicMaterial);

	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.75f, 0.70f, 0.58f);
	paperMaterial.ambientStrength = 0.34f;
	paperMaterial.diffuseColor = glm::vec3(0.88f, 0.83f, 0.70f);
	paperMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	paperMaterial.shininess = 6.0f;
	paperMaterial.tag = "paperMaterial";
	m_objectMaterials.push_back(paperMaterial);

	OBJECT_MATERIAL clothMaterial;
	clothMaterial.ambientColor = glm::vec3(0.32f, 0.34f, 0.36f);
	clothMaterial.ambientStrength = 0.34f;
	clothMaterial.diffuseColor = glm::vec3(0.68f, 0.70f, 0.72f);
	clothMaterial.specularColor = glm::vec3(0.14f, 0.14f, 0.14f);
	clothMaterial.shininess = 10.0f;
	clothMaterial.tag = "clothMaterial";
	m_objectMaterials.push_back(clothMaterial);

	OBJECT_MATERIAL pencilMaterial;
	pencilMaterial.ambientColor = glm::vec3(0.45f, 0.34f, 0.12f);
	pencilMaterial.ambientStrength = 0.34f;
	pencilMaterial.diffuseColor = glm::vec3(0.90f, 0.66f, 0.16f);
	pencilMaterial.specularColor = glm::vec3(0.20f, 0.18f, 0.12f);
	pencilMaterial.shininess = 12.0f;
	pencilMaterial.tag = "pencilMaterial";
	m_objectMaterials.push_back(pencilMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Uses two point-style lights: a warm key light and a cool
 *  colored fill light. Together they keep all objects visible
 *  while supplying ambient, diffuse, and specular lighting.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	m_pShaderManager->setVec3Value("globalAmbientColor", 0.09f, 0.09f, 0.11f);

	// Warm key light - point light above and to the front-left.
	m_pShaderManager->setVec3Value("lightSources[0].position", -7.0f, 11.0f, 8.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.10f, 0.09f, 0.08f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.96f, 0.84f, 0.70f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.00f, 0.94f, 0.84f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 30.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.72f);

	// Cool blue fill light - colored secondary point light.
	m_pShaderManager->setVec3Value("lightSources[1].position", 7.0f, 7.5f, 3.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.04f, 0.05f, 0.09f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.28f, 0.46f, 0.86f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.38f, 0.58f, 0.98f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 24.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.44f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Loads all textures, materials, lights, and primitive meshes
 *  required by the final project.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	CreateGLTexture("textures/desk_wood.png", "deskWood");
	CreateGLTexture("textures/black_plastic.png", "blackPlastic");
	CreateGLTexture("textures/brushed_metal.png", "brushedMetal");
	CreateGLTexture("textures/screen_wallpaper.png", "screenWallpaper");
	CreateGLTexture("textures/mug_ceramic.png", "mugCeramic");
	CreateGLTexture("textures/book_cover.png", "bookCover");
	CreateGLTexture("textures/paper_pages.png", "paperPages");
	CreateGLTexture("textures/pencil_holder.png", "pencilHolder");

	BindGLTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderDesk()
 ***********************************************************/
void SceneManager::RenderDesk()
{
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 10.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));

	SetShaderTexture("deskWood");
	SetTextureUVScale(6.0f, 3.0f);
	SetShaderMaterial("deskMaterial");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderMonitor()
 *
 *  The monitor is the required complex object. The stand
 *  connects the display body directly to the base, and the
 *  base rests directly on the desktop plane.
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	/***********************************************************
	 * MONITOR FRAME
	 ***********************************************************/
	SetTransformations(
		glm::vec3(6.0f, 3.6f, 0.45f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 4.5f, 0.0f));

	SetShaderTexture("blackPlastic");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderMaterial("plasticMaterial");

	m_basicMeshes->DrawBoxMesh();


	/***********************************************************
	 * MONITOR SCREEN
	 ***********************************************************/
	SetTransformations(
		glm::vec3(5.45f, 3.05f, 0.08f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 4.5f, 0.32f));

	SetShaderTexture("screenWallpaper");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("screenMaterial");

	m_basicMeshes->DrawBoxMesh();


	/***********************************************************
	 * VERTICAL MONITOR ARM
	 *
	 * The arm extends from the base into the lower portion
	 * of the monitor frame so no visible gaps appear.
	 ***********************************************************/
	SetTransformations(
		glm::vec3(0.48f, 2.50f, 0.48f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 1.55f, 0.0f));

	SetShaderTexture("brushedMetal");
	SetTextureUVScale(1.0f, 2.0f);
	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawBoxMesh();


	/***********************************************************
	 * MONITOR BASE
	 *
	 * The base sits directly on the desktop plane. A very
	 * small overlap prevents it from appearing to float.
	 ***********************************************************/
	SetTransformations(
		glm::vec3(2.8f, 0.34f, 1.65f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.18f, 0.0f));

	SetShaderTexture("brushedMetal");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMug()
 *
 *  Cylinder + torus create a low-polygon coffee mug.
 ***********************************************************/
void SceneManager::RenderMug()
{
	// Mug body.
	SetTransformations(
		glm::vec3(0.86f, 1.35f, 0.86f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.7f, 0.02f, 1.8f));
	SetShaderTexture("mugCeramic");
	SetTextureUVScale(1.5f, 1.5f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawCylinderMesh();

	// Handle. The torus is rotated vertically and overlaps the mug wall.
	SetTransformations(
		glm::vec3(0.62f, 0.62f, 0.62f),
		0.0f, 0.0f, 90.0f,
		glm::vec3(-3.92f, 0.73f, 1.8f));
	SetShaderTexture("mugCeramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramicMaterial");
	m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 *  RenderBooks()
 *
 *  Three books use boxes for covers and slightly smaller boxes
 *  for page blocks. Together they form one completed stack.
 ***********************************************************/
void SceneManager::RenderBooks()
{
	const float bookY[3] = { 0.16f, 0.47f, 0.78f };
	const float bookRot[3] = { -4.0f, 3.0f, -2.0f };
	const glm::vec3 bookPos[3] = {
		glm::vec3(4.2f, bookY[0], 0.75f),
		glm::vec3(4.15f, bookY[1], 0.72f),
		glm::vec3(4.22f, bookY[2], 0.70f)
	};

	for (int i = 0; i < 3; i++)
	{
		SetTransformations(
			glm::vec3(3.25f, 0.28f, 1.95f),
			0.0f, bookRot[i], 0.0f,
			bookPos[i]);
		SetShaderTexture("bookCover");
		SetTextureUVScale(1.0f, 1.0f);
		SetShaderMaterial("clothMaterial");
		m_basicMeshes->DrawBoxMesh();

		SetTransformations(
			glm::vec3(3.02f, 0.19f, 1.78f),
			0.0f, bookRot[i], 0.0f,
			glm::vec3(bookPos[i].x + 0.04f, bookPos[i].y + 0.01f, bookPos[i].z));
		SetShaderTexture("paperPages");
		SetTextureUVScale(1.0f, 2.0f);
		SetShaderMaterial("paperMaterial");
		m_basicMeshes->DrawBoxMesh();
	}
}

/***********************************************************
 *  RenderPencilHolder()
 *
 *  A textured cylinder holds three pencil assemblies. Each
 *  pencil uses a thin cylinder and a cone tip.
 ***********************************************************/
void SceneManager::RenderPencilHolder()
{
	// Holder body.
	SetTransformations(
		glm::vec3(1.05f, 1.55f, 1.05f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(5.5f, 0.02f, -2.05f));
	SetShaderTexture("pencilHolder");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderMaterial("clothMaterial");
	m_basicMeshes->DrawCylinderMesh();

	const glm::vec3 pencilPos[3] = {
		glm::vec3(5.25f, 0.95f, -2.05f),
		glm::vec3(5.52f, 0.96f, -1.88f),
		glm::vec3(5.74f, 0.94f, -2.18f)
	};
	const float pencilRot[3] = { -5.0f, 3.0f, 7.0f };
	const glm::vec4 pencilColors[3] = {
		glm::vec4(0.92f, 0.68f, 0.16f, 1.0f),
		glm::vec4(0.78f, 0.18f, 0.14f, 1.0f),
		glm::vec4(0.20f, 0.45f, 0.82f, 1.0f)
	};

	for (int i = 0; i < 3; i++)
	{
		SetTransformations(
			glm::vec3(0.13f, 2.15f, 0.13f),
			0.0f, 0.0f, pencilRot[i],
			pencilPos[i]);
		SetShaderColor(
			pencilColors[i].r,
			pencilColors[i].g,
			pencilColors[i].b,
			pencilColors[i].a);
		SetShaderMaterial("pencilMaterial");
		m_basicMeshes->DrawCylinderMesh();

		SetTransformations(
			glm::vec3(0.17f, 0.34f, 0.17f),
			0.0f, 0.0f, pencilRot[i],
			glm::vec3(pencilPos[i].x, pencilPos[i].y + 2.12f, pencilPos[i].z));
		SetShaderColor(0.72f, 0.55f, 0.33f, 1.0f);
		SetShaderMaterial("pencilMaterial");
		m_basicMeshes->DrawConeMesh();
	}
}

/***********************************************************
 *  RenderScene()
 *
 *  Keeps the final scene logical and modular by delegating
 *  each completed real-world object to its own function.
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDesk();
	RenderMonitor();
	RenderMug();
	RenderBooks();
	RenderPencilHolder();
}
