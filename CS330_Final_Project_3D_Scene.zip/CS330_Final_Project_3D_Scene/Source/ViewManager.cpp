///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <iostream>
#include <cmath>

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of global variables and settings
namespace
{
	// OpenGL window dimensions
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera used for viewing the scene
	Camera* g_pCamera = nullptr;

	// mouse position variables
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// camera orientation
	float gYaw = -90.0f;
	float gPitch = -10.0f;

	// frame timing
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// actual camera travel speed
	// mouse wheel changes this value
	float gCameraTravelSpeed = 5.0f;

	const float MIN_CAMERA_SPEED = 1.0f;
	const float MAX_CAMERA_SPEED = 20.0f;

	// false = perspective
	// true = orthographic
	bool bOrthographicProjection = false;

	// used so P/O only activate once per key press
	bool gPKeyWasDown = false;
	bool gOKeyWasDown = false;

	/***********************************************************
	 *  UpdateCameraDirection()
	 *
	 *  Calculates the camera's front direction from yaw
	 *  and pitch values.
	 ***********************************************************/
	void UpdateCameraDirection()
	{
		if (NULL == g_pCamera)
		{
			return;
		}

		glm::vec3 direction;

		direction.x =
			cos(glm::radians(gYaw)) *
			cos(glm::radians(gPitch));

		direction.y =
			sin(glm::radians(gPitch));

		direction.z =
			sin(glm::radians(gYaw)) *
			cos(glm::radians(gPitch));

		g_pCamera->Front =
			glm::normalize(direction);
	}

	/***********************************************************
	 *  SetPerspectiveCamera()
	 *
	 *  Places the camera above and in front of the scene so
	 *  both the monitor and desktop plane can be seen.
	 ***********************************************************/
	void SetPerspectiveCamera()
	{
		if (NULL == g_pCamera)
		{
			return;
		}

		g_pCamera->Position =
			glm::vec3(
				0.0f,
				6.5f,
				13.0f);

		g_pCamera->Up =
			glm::vec3(
				0.0f,
				1.0f,
				0.0f);

		g_pCamera->Zoom = 60.0f;

		// look slightly downward toward the monitor
		gYaw = -90.0f;
		gPitch = -10.0f;

		UpdateCameraDirection();

		gFirstMouse = true;
	}

	/***********************************************************
	 *  SetOrthographicCamera()
	 *
	 *  Places the camera directly in front of the monitor.
	 *  This makes the horizontal desktop plane edge-on so
	 *  that it is not visible in orthographic mode.
	 ***********************************************************/
	void SetOrthographicCamera()
	{
		if (NULL == g_pCamera)
		{
			return;
		}

		g_pCamera->Position =
			glm::vec3(
				0.0f,
				4.5f,
				12.0f);

		g_pCamera->Up =
			glm::vec3(
				0.0f,
				1.0f,
				0.0f);

		gYaw = -90.0f;
		gPitch = 0.0f;

		UpdateCameraDirection();

		gFirstMouse = true;
	}
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	// create the camera
	g_pCamera = new Camera();

	// establish the default perspective view
	SetPerspectiveCamera();
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  Creates the main OpenGL display window and registers
 *  the mouse callbacks.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout
			<< "Failed to create GLFW window"
			<< std::endl;

		glfwTerminate();

		return NULL;
	}

	glfwMakeContextCurrent(window);

	// mouse movement controls camera orientation
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// mouse wheel controls camera movement speed
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// capture the mouse for unrestricted camera rotation
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// enable blending for transparent rendering
	glEnable(GL_BLEND);

	glBlendFunc(
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Rotates the camera when the mouse moves in either projection mode.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	(void)window;

	if (NULL == g_pCamera)
	{
		return;
	}

	// prevent a large movement on the first mouse event
	if (gFirstMouse)
	{
		gLastX =
			static_cast<float>(xMousePos);

		gLastY =
			static_cast<float>(yMousePos);

		gFirstMouse = false;
	}

	// calculate cursor movement
	float xOffset =
		static_cast<float>(xMousePos) -
		gLastX;

	float yOffset =
		gLastY -
		static_cast<float>(yMousePos);

	// save current mouse coordinates
	gLastX =
		static_cast<float>(xMousePos);

	gLastY =
		static_cast<float>(yMousePos);

	// mouse sensitivity
	const float mouseSensitivity = 0.10f;

	xOffset *= mouseSensitivity;
	yOffset *= mouseSensitivity;

	// update yaw and pitch
	gYaw += xOffset;
	gPitch += yOffset;

	// prevent the camera from flipping upside down
	if (gPitch > 89.0f)
	{
		gPitch = 89.0f;
	}

	if (gPitch < -89.0f)
	{
		gPitch = -89.0f;
	}

	UpdateCameraDirection();
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Changes the speed used by W/A/S/D/Q/E.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	(void)window;
	(void)xOffset;

	// wheel up increases speed
	// wheel down decreases speed
	gCameraTravelSpeed +=
		static_cast<float>(yOffset);

	// keep speed within a practical range
	if (gCameraTravelSpeed < MIN_CAMERA_SPEED)
	{
		gCameraTravelSpeed =
			MIN_CAMERA_SPEED;
	}

	if (gCameraTravelSpeed > MAX_CAMERA_SPEED)
	{
		gCameraTravelSpeed =
			MAX_CAMERA_SPEED;
	}

	// print the speed so scroll-wheel input
	// can be easily verified while testing
	std::cout
		<< "Camera movement speed: "
		<< gCameraTravelSpeed
		<< std::endl;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Handles camera movement and projection switching.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Escape closes the window
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	if (NULL == g_pCamera)
	{
		return;
	}

	// distance camera should move this frame
	float cameraVelocity =
		gCameraTravelSpeed *
		gDeltaTime;

	// current forward direction
	glm::vec3 forwardDirection =
		glm::normalize(
			g_pCamera->Front);

	// current right direction
	glm::vec3 rightDirection =
		glm::normalize(
			glm::cross(
				forwardDirection,
				g_pCamera->Up));

	/***********************************************************
	 * W / S = Forward and Backward
	 ***********************************************************/

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->Position +=
			forwardDirection *
			cameraVelocity;
	}

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->Position -=
			forwardDirection *
			cameraVelocity;
	}

	/***********************************************************
	 * A / D = Left and Right
	 ***********************************************************/

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->Position -=
			rightDirection *
			cameraVelocity;
	}

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->Position +=
			rightDirection *
			cameraVelocity;
	}

	/***********************************************************
	 * Q / E = Up and Down
	 ***********************************************************/

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position.y +=
			cameraVelocity;
	}

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position.y -=
			cameraVelocity;
	}

	/***********************************************************
	 * P = Perspective projection (camera position/orientation preserved)
	 ***********************************************************/

	bool pKeyDown =
		glfwGetKey(
			m_pWindow,
			GLFW_KEY_P) == GLFW_PRESS;

	if (pKeyDown &&
		!gPKeyWasDown)
	{
		bOrthographicProjection = false;

		std::cout
			<< "Perspective projection"
			<< std::endl;
	}

	gPKeyWasDown =
		pKeyDown;

	/***********************************************************
	 * O = Orthographic projection (camera position/orientation preserved)
	 ***********************************************************/

	bool oKeyDown =
		glfwGetKey(
			m_pWindow,
			GLFW_KEY_O) == GLFW_PRESS;

	if (oKeyDown &&
		!gOKeyWasDown)
	{
		bOrthographicProjection = true;

		std::cout
			<< "Orthographic projection"
			<< std::endl;
	}

	gOKeyWasDown =
		oKeyDown;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Prepares the view and projection matrices used to
 *  display the scene.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// calculate frame time
	float currentFrame =
		static_cast<float>(
			glfwGetTime());

	gDeltaTime =
		currentFrame -
		gLastFrame;

	gLastFrame =
		currentFrame;

	// process keyboard input
	ProcessKeyboardEvents();

	// retrieve camera view matrix
	view =
		g_pCamera->GetViewMatrix();

	/***********************************************************
	 * Projection Matrix
	 ***********************************************************/

	if (bOrthographicProjection)
	{
		// 2D-style orthographic projection
		projection =
			glm::ortho(
				-8.0f,
				8.0f,
				-6.4f,
				6.4f,
				0.1f,
				100.0f);
	}
	else
	{
		// normal 3D perspective projection
		projection =
			glm::perspective(
				glm::radians(
					g_pCamera->Zoom),

				static_cast<float>(
					WINDOW_WIDTH) /
				static_cast<float>(
					WINDOW_HEIGHT),

				0.1f,
				100.0f);
	}

	/***********************************************************
	 * Send camera data to the shaders
	 ***********************************************************/

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}